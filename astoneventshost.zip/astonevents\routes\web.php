<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home')->middleware('auth');

Route::get('/display/{category}',[App\Http\Controllers\EventController::class, 'display'])->name('display_events');

Route::get('/show/{EventID}',[App\Http\Controllers\EventController::class, 'show'])->name('display_event');

Route::get('/update_interest/{EventID}',[App\Http\Controllers\EventController::class, 'update_interest'])->name('update_interest');

Route::get('/my_events',[App\Http\Controllers\EventController::class, 'my_events'])->name('display_org_events')->middleware('auth');

Route::get('/edit/{EventID}',[App\Http\Controllers\EventController::class, 'edit'])->name('edit_event')->middleware('auth');

Route::post('/save',[App\Http\Controllers\EventController::class, 'save'])->name('save_event')->middleware('auth');

Route::get('/create',[App\Http\Controllers\EventController::class, 'create'])->name('create_event')->middleware('auth');

Route::post('/add',[App\Http\Controllers\EventController::class, 'add'])->name('add_event')->middleware('auth');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
