<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    use HasFactory;

    protected $primaryKey = 'EventID';
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'EventID',
        'OrganiserID',
        'Name',
        'Category',
        'DateAndTime',
        'Description',
        'Location',
        'InterestRank'
    ];

    public function category()
    {
        return $this->hasOne(Category::class, 'EventID');
    }

}
