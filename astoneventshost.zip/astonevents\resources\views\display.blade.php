
<!-- It extends the Laravel default Blade template layouts.app (you could find it in
resources/layouts folder). For the ‘content’ section, this child view defines an html table to display
the account information. -->

<!DOCTYPE html>
<html>

@extends('layouts.app')
@section('content')

<div class="container">
   <div class="row justify-content-center">
     <div class="col-md-8">
       <div class="card">
         <div class="card-header"></div>
          <div class="card-body">
          @if (session('status'))
            <div class="alert alert-success">
              {{ session('status') }}
            </div>
          @endif
   <table class="sortable">
     <thead>
       <tr>
         <th> Name</th><th> Description</th><th> Time</th><th> Interest Rank</th>
       </tr>
      </thead>
       <tbody>
          @foreach($events as $event)
          <tr class="item">
          <td><a href="{{ route('display_event', ['EventID'=>$event->EventID]) }}" class="btn btnprimary">{{$event->Name}} </a></td>
           <td> {{$event->Description}} </td>
          <td> {{$event->DateAndTime}} </td>
          <td> {{$event->InterestRank}} </td>
          </tr>
          @endforeach
       </tbody>
   </table>

   @if (count($errors) > 0)
     <div class="alert alert-danger">
         <ul>
             @foreach ($errors->all() as $error)
                 <li>{{ $error }}</li>
             @endforeach
         </ul>
     </div>
   @endif

   <script src="https://www.kryogenix.org/code/browser/sorttable/sorttable.js"></script>

   </div>
   </div>
   </div>
   </div>
</div>
@endsection

</html>
