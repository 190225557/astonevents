
<!DOCTYPE html>
<html>
 <head>
   <title>Event </title>
 </head>
 <body>
   <form method="POST" action="{{ route('save_event') }}" enctype="multipart/form-data">
     @csrf
     @foreach($event as $detail)
       <dl>
         <dt>Event Name:</dt>
        <dd><textarea id="name" name="name" rows="4" cols="50">{{$detail->Name}}</textarea></dd>
        <br />
        <dt>Photo(s) here</dt>
        <input type="file" id="image1" name="image1">
        <br />
        <input type="file" id="image2" name="image2">
        <br />
        <input type="file" id="image3" name="image3">
        <br />
        <dt>Description:</dt>
        <dd><textarea id="description" name="description" rows="4" cols="50">{{$detail->Description}}</textarea></dd>
        <br />
        <dt>Location:</dt>
        <dd><textarea id="location" name="location" rows="4" cols="50">{{$detail->Location}}</textarea></dd>
        <br />
        <dt>Date & Time:</dt>
        <dd><p> Current date and time: </p>{{$detail->DateAndTime}}<br /><input type="datetime-local" id="date" name="date"></dd>
        <br />
        <dd><textarea hidden id="eid" name="eid">{{$detail->EventID}}</textarea></dd>
        <button type="submit" class="btn btn-primary">Save changes</button>
        <br />
      </dl>
    @endforeach
  </form>

  @if (count($errors) > 0)
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
  @endif

 </body>
</html>
