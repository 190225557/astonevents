<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Aston Events</title>

    </head>

    <body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
            <?php if(Route::has('login')): ?>
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 underline">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
            <?php endif; ?>
                  </div>
                  <div>
                    <br>
                    <a href="<?php echo e(route('display_events', ['category'=>'Sport'])); ?>" class="text-sm text-gray-700 underline">Display Events Under Category 'Sport'</a>
                    <br>
                    <a href="<?php echo e(route('display_events', ['category'=>'Culture'])); ?>" class="text-sm text-gray-700 underline">Display Events Under Category 'Culture'</a>
                    <br>
                    <a href="<?php echo e(route('display_events', ['category'=>'Other'])); ?>" class="text-sm text-gray-700 underline">Display Events Under Category 'Other'</a>
                </div>


        </div>

    </body>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u-190225557/public_html/astonevents/resources/views/welcome.blade.php ENDPATH**/ ?>