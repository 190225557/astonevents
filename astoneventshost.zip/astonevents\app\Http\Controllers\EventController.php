<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Event;
use App\Models\User;
use App\Models\Photo;
//use App\Http\Controllers\DB;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;

use Gate;

use Session;

use Carbon\Carbon;

class EventController extends Controller
{

  //showing one event
  public function show($id){

    //finding particular event by its EventID
    $event = Event::where('EventID', $id)->get();

    //gets the organiser ID associated with event
    foreach ($event as $detail) {
      $orgID = $detail->OrganiserID;
    }

    //getting the OrganiserID
    $organiser = User::where('OrganiserID', $orgID)->get();

    //getting the photos associated with the event
    $photos = Photo::where('EventID', $id)->get();

    return view('/show')->with('event', $event)->with('organiser', $organiser)->with('photos', $photos);
  }

  //displays all the events from the database split by category
  public function display($category){

     $eventsQuery = Event::where('Category', $category)->get();

     return view('/display', array('events'=>$eventsQuery));
   }

   //displays the events that are organised by an organiser
   public function my_events(){

     //Get the currently authenticated user's ID...
     $auth_id = Auth::id();

     //get the events associated with the organiser's ID
     $events = Event::where('OrganiserID', $auth_id)->get();

     return view('/organiserevents', array('events'=>$events));
   }

   //edit the Organiser's chosen event
   public function edit($id){
     //finding particular event by its EventID
     $event = Event::where('EventID', $id)->get();

     return view('/editevent')->with('event', $event);
   }

   //save the Organiser's changes to chosen event
   public function save(Request $request){

     $request->validate([
       'name' => 'required|max:50',
       'description' => 'required|max:255',
       'location' => 'required|max:255'
        ]);

     //getting the event name from the view
     $new_name = $request->post('name');

     //getting the description from the view
     $new_description = $request->post('description');

     //getting the description from the view
     $new_location = $request->post('location');

     //getting photos from the view
     $new_photo1 = $request->post('image1');
     $new_photo2 = $request->post('image2');
     $new_photo3 = $request->post('image3');

     //getting the event id from the view
     $event_id = $request->post('eid');

     //updating db with changes to specific event
     DB::table('events')->where('EventID', $event_id)->update(['Name' => $new_name]);
     DB::table('events')->where('EventID', $event_id)->update(['Description' => $new_description]);
     DB::table('events')->where('EventID', $event_id)->update(['Location' => $new_location]);
     //do same as above for data/time

     //validate file type of the photos
     $request->validate([
          'image1' => 'mimes:jpeg,png,jpg',
          'image2' => 'mimes:jpeg,png,jpg',
          'image3' => 'mimes:jpeg,png,jpg'
      ]);

      //set the images to null as the organsier might not
      //upload any
      $file1 = null;
      $file2 = null;
      $file3 = null;

      foreach (range(1,3) as $index){
         $imageNo = $index;

         //if user has uploaded an image
         if ($request->hasFile('image' . $imageNo)) {
             //if the image is valid
             if ($request->file('image' . $imageNo)->isValid()) {

                 //store the first image
                 if ($imageNo == 1){
                 // Save the file locally in the storage/app/public/ folder under a new folder named /photo
                 $file1 = $request->file('image' . $imageNo)->store('photo', 'public');
                 }
                 //store the second image
                 elseif($imageNo == 2){
                   $file2 = $request->file('image' . $imageNo)->store('photo', 'public');
                 }
                 //store the third image
                 elseif($imageNo == 3){
                   $file3 = $request->file('image' . $imageNo)->store('photo', 'public');
                 }
           }
           //if file not valid
           else{
             abort(500, 'Could not upload image :(');
           }
         }
       }

       DB::table('photos')->where('EventID', $event_id)->update([
       "Photo1" => $file1,
       "Photo2" => $file2,
       "Photo3" => $file3]);

     return redirect('/home');
   }

    //gets the event id so it can update the interest by 1
    public function update_interest($id){
       DB::table('events')->where('EventID', $id)->increment('InterestRank');

       return redirect('/home');
     }

     //the page where you can enter the info for a new event
     public function create(){

       return view('/create');
     }

     //add details of new event to the database
     public function add(Request $request){

       //validate input data
       $request->validate([
         'name' => 'required|max:50',
         'description' => 'required|max:255',
         'location' => 'required|max:255',
         'category' => 'required|in:Sport,Culture,Other'
          ]);

       //create the event and store in DB first, then do images after
       //due to the one to many relationship between event and image
       $newEvent = Event::create(['OrganiserID' => Auth::id(),
       'Name' => $request->post('name'),
       'Category' => $request->post('category'),
       'Description' => $request->post('description'),
       'DateAndTime' => $request->post('date'),
       'Location' => $request->post('location'),
       'InterestRank' => 0
        ]);

        //get the event ID of the event that was just inserted in DB, to use
        //when inserting images into DB
        $newEventID = $newEvent->EventID;

        //validate file type
        $request->validate([
             'image1' => 'mimes:jpeg,png,jpg',
             'image2' => 'mimes:jpeg,png,jpg',
             'image3' => 'mimes:jpeg,png,jpg'
         ]);

         //set the images to null as the organsier might not
         //upload any
         $file1 = null;
         $file2 = null;
         $file3 = null;

         foreach (range(1,3) as $index){
            $imageNo = $index;

            //if user has uploaded an image
            if ($request->hasFile('image' . $imageNo)) {
                //if the image is valid
                if ($request->file('image' . $imageNo)->isValid()) {

                    //store the first image
                    if ($imageNo == 1){
                    // Save the file locally in the storage/app/public/ folder under a new folder named /photo
                    $file1 = $request->file('image' . $imageNo)->store('photo', 'public');
                    }
                    //store the second image
                    elseif($imageNo == 2){
                      $file2 = $request->file('image' . $imageNo)->store('photo', 'public');
                    }
                    //store the third image
                    elseif($imageNo == 3){
                      $file3 = $request->file('image' . $imageNo)->store('photo', 'public');
                    }
              }
              //if file not valid
              else{
                abort(500, 'Could not upload image :(');
              }
            }
          }

          //Store images in the database
          Photo::create(["EventID" => $newEventID,
          ("Photo1") => $file1,
          ("Photo2") => $file2,
          ("Photo3") => $file3]);

          return view('home');

        }
}
