<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePhotosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('photos');

        Schema::create('photos', function (Blueprint $table) {
          $table->unsignedBigInteger('EventID');
          $table->foreign('EventID')->references('EventID')->on('events')->onDelete('cascade');
          $table->string('Photo1', 256)->nullable();
          $table->string('Photo2', 256)->nullable();
          $table->string('Photo3', 256)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('photos');
    }
}
