
<!-- It extends the Laravel default Blade template layouts.app (you could find it in
resources/layouts folder). For the ‘content’ section, this child view defines an html table to display
the account information. -->

<!DOCTYPE html>
<html>


<?php $__env->startSection('content'); ?>

<div class="container">
   <div class="row justify-content-center">
     <div class="col-md-8">
       <div class="card">
         <div class="card-header"></div>
          <div class="card-body">
          <?php if(session('status')): ?>
            <div class="alert alert-success">
              <?php echo e(session('status')); ?>

            </div>
          <?php endif; ?>
   <table class="sortable">
     <thead>
       <tr>
         <th> Name</th><th> Description</th><th> Time</th><th> Interest Rank</th>
       </tr>
      </thead>
       <tbody>
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class="item">
          <td><a href="<?php echo e(route('display_event', ['EventID'=>$event->EventID])); ?>" class="btn btnprimary"><?php echo e($event->Name); ?> </a></td>
           <td> <?php echo e($event->Description); ?> </td>
          <td> <?php echo e($event->DateAndTime); ?> </td>
          <td> <?php echo e($event->InterestRank); ?> </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </tbody>
   </table>

   <?php if(count($errors) > 0): ?>
     <div class="alert alert-danger">
         <ul>
             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><?php echo e($error); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
     </div>
   <?php endif; ?>

   <script src="https://www.kryogenix.org/code/browser/sorttable/sorttable.js"></script>

   </div>
   </div>
   </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\astonevents\resources\views//display.blade.php ENDPATH**/ ?>