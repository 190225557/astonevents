
<!DOCTYPE html>
<html>

@extends('layouts.app')
@section('content')

<div class="container">
   <div class="row justify-content-center">
     <div class="col-md-8">
       <div class="card">
         <div class="card-header">My Events</div>
          <div class="card-body">
          @if (session('status'))
            <div class="alert alert-success">
              {{ session('status') }}
            </div>
          @endif
   <table class="sortable" id="mytable">
     <thead>
       <tr>
         <th> Name</th><th> Description</th><th> Time</th><th> Interest Rank</th>
       </tr>
      </thead>
       <tbody>
          @foreach($events as $event)
          <tr class="item">
          <td><a href="{{ route('edit_event', ['EventID'=>$event->EventID]) }}" class="btn btnprimary">{{$event->Name}} </a></td>
           <td> {{$event->Description}} </td>
          <td> {{$event->DateAndTime}} </td>
          <td> {{$event->InterestRank}} </td>
          </tr>
          @endforeach
       </tbody>
   </table>
   <script src="https://www.kryogenix.org/code/browser/sorttable/sorttable.js"></script>
   </div>
   </div>
   </div>
   </div>
</div>
@endsection

</html>
