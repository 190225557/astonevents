<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::dropIfExists('events');

      Schema::create('events', function (Blueprint $table) {
          $table->bigIncrements('EventID');
          $table->unsignedBigInteger('OrganiserID');
          $table->foreign('OrganiserID')->references('OrganiserID')->on('users')->onDelete('cascade');
          $table->string('Name');
          $table->string('Category');
          $table->dateTime('DateAndTime', $precision = 0)->nullable();
          $table->longText('Description');
          $table->longText('Location');
          $table->integer('InterestRank');
      });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('events');
    }
}
