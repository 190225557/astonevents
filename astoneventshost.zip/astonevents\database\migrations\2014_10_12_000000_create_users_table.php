<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::dropIfExists('users');

        Schema::create('users', function (Blueprint $table) {
            //$table->unsignedBigInteger('OrganiserID')->primary();
            $table->bigIncrements('OrganiserID');
            //$table->unsignedBigInteger('OrganiserID')->primary();
            //$table->unsignedBigInteger('OrganiserID');
            $table->string('Name');
            $table->string('Email');
            $table->timestamp('EmailVerifiedAt')->nullable();
            $table->string('Phone');
            $table->string('Password');
            $table->rememberToken();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
