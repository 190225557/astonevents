

<!DOCTYPE html>
<html>
 <head>
   <title>Event </title>
 </head>

 <body>
   @if (session('status'))
     <div class="alert alert-success">
       {{ session('status') }}
     </div>
   @endif
   <form method="POST" action="{{ route('add_event') }}" enctype="multipart/form-data">
     @csrf
     <dl>
      <strong><dt>Create an event:</dt></strong>
      <br />
      <dt>Name:</dt>
      <dd><textarea id="name" name="name" rows="2" cols="20">Name</textarea></dd>
      <br />
      <dt>Photo(s) here</dt>
      <input type="file" id="image1" name="image1">
      <br />
      <input type="file" id="image2" name="image2">
      <br />
      <input type="file" id="image3" name="image3">
      <br />
      <dt>Description:</dt>
      <dd><textarea id="description" name="description" rows="4" cols="50">Description</textarea></dd>
      <br />
      <dt>Category:</dt>
      <dd><textarea id="category" name="category" rows="2" cols="20">Category (Sport, Culture or Other)</textarea></dd>
      <br />
      <dt>Location:</dt>
      <dd><textarea id="location" name="location" rows="4" cols="50">Location</textarea></dd>
      <br />
      <dt>Date & Time:</dt>
      <dd><input type="datetime-local" id="date" name="date" ></dd>
      <br />
      <button type="submit" class="btn btn-primary">Create Event</button>
      <br />
    </dl>
  </form>
  @if (count($errors) > 0)
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
  @endif
 </body>
</html>
