
<!DOCTYPE html>
<html>
 <head>
   <title>Event </title>
 </head>
 <body>
     <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <dl>
        <strong><dt><?php echo e($detail->Name); ?></dt></strong>
        <br />
        <dt>Photo(s):</dt>
        <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(!empty($photo->Photo1)): ?>
          <dd><img src="<?php echo e(asset($photo->Photo1)); ?>" height="250" /></dd>
          <br />
          <?php endif; ?>
          <?php if(!empty($photo->Photo2)): ?>
          <dd><img src="<?php echo e(asset($photo->Photo2)); ?>" height="250" /></dd>
          <br />
          <?php endif; ?>
          <?php if(!empty($photo->Photo3)): ?>
          <dd><img src="<?php echo e(asset($photo->Photo3)); ?>" height="250" /></dd>
          <br />
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <dt>Description:</dt>
        <dd><?php echo e($detail->Description); ?></dd>
        <br />
        <dt>Location:</dt>
        <dd><?php echo e($detail->Location); ?></dd>
        <br />
        <dt>Date & Time:</dt>
        <dd><?php echo e($detail->DateAndTime); ?></dd>
        <br />
        <dt>Interest Ranking:</dt>
        <dd><?php echo e($detail->InterestRank); ?></dd>
        <br />
        <a href="<?php echo e(route('update_interest' , ['EventID'=>$detail->EventID])); ?>" class="btn btn-primary"><button type="button">I'm Interested</button></a>
        <?php $__currentLoopData = $organiser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <dt><a href="mailto:<?php echo e($detail->Email); ?>">Email the event organiser: <?php echo e($detail->Email); ?></a></dt>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </dl>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if(count($errors) > 0): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>

 </body>
</html>
<?php /**PATH /home/u-190225557/public_html/astonevents/resources/views//show.blade.php ENDPATH**/ ?>