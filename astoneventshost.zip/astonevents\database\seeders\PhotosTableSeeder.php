<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;
use App\Models\User;
use App\Models\Event;

class PhotosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      //created an instance of Faker class to the variable $faker
      $faker = Faker::create();

      $events = Event::all()->pluck('EventID')->toArray();

      //generate 10 records for the accounts table
      foreach (range(1,10) as $index) {
        DB::table('photos')->insert([
          'EventID' =>$faker->unique()->randomElement($events),
          //'EventID' => $faker->unique()->randomDigit,
          'Photo1' => $faker->lexify('???????????????????').'.jpg',
          'Photo2' => $faker->lexify('???????????????????').'.jpg',
          'Photo3' => $faker->lexify('???????????????????').'.jpg'
      ]);
      }
    }
}
