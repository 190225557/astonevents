

<!DOCTYPE html>
<html>
 <head>
   <title>Event </title>
 </head>

 <body>
   <?php if(session('status')): ?>
     <div class="alert alert-success">
       <?php echo e(session('status')); ?>

     </div>
   <?php endif; ?>
   <form method="POST" action="<?php echo e(route('add_event')); ?>" enctype="multipart/form-data">
     <?php echo csrf_field(); ?>
     <dl>
      <strong><dt>Create an event:</dt></strong>
      <br />
      <dt>Name:</dt>
      <dd><textarea id="name" name="name" rows="2" cols="20">Name</textarea></dd>
      <br />
      <dt>Photo(s) here</dt>
      <input type="file" id="image1" name="image1">
      <br />
      <input type="file" id="image2" name="image2">
      <br />
      <input type="file" id="image3" name="image3">
      <br />
      <dt>Description:</dt>
      <dd><textarea id="description" name="description" rows="4" cols="50">Description</textarea></dd>
      <br />
      <dt>Category:</dt>
      <dd><textarea id="category" name="category" rows="2" cols="20">Category (Sport, Culture or Other)</textarea></dd>
      <br />
      <dt>Location:</dt>
      <dd><textarea id="location" name="location" rows="4" cols="50">Location</textarea></dd>
      <br />
      <dt>Date & Time:</dt>
      <dd><input type="datetime-local" id="date" name="date" ></dd>
      <br />
      <button type="submit" class="btn btn-primary">Create Event</button>
      <br />
    </dl>
  </form>
  <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
  <?php endif; ?>
 </body>
</html>
<?php /**PATH /home/u-190225557/public_html/astonevents/resources/views//create.blade.php ENDPATH**/ ?>