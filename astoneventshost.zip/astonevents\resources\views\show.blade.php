
<!DOCTYPE html>
<html>
 <head>
   <title>Event </title>
 </head>
 <body>
     @foreach($event as $detail)
       <dl>
        <strong><dt>{{$detail->Name}}</dt></strong>
        <br />
        <dt>Photo(s):</dt>
        @foreach($photos as $photo)
          @if(!empty($photo->Photo1))
          <dd><img src="{{ asset($photo->Photo1) }}" height="250" /></dd>
          <br />
          @endif
          @if(!empty($photo->Photo2))
          <dd><img src="{{ asset($photo->Photo2) }}" height="250" /></dd>
          <br />
          @endif
          @if(!empty($photo->Photo3))
          <dd><img src="{{ asset($photo->Photo3) }}" height="250" /></dd>
          <br />
          @endif
        @endforeach
        <dt>Description:</dt>
        <dd>{{$detail->Description}}</dd>
        <br />
        <dt>Location:</dt>
        <dd>{{$detail->Location}}</dd>
        <br />
        <dt>Date & Time:</dt>
        <dd>{{$detail->DateAndTime}}</dd>
        <br />
        <dt>Interest Ranking:</dt>
        <dd>{{$detail->InterestRank}}</dd>
        <br />
        <a href="{{ route('update_interest' , ['EventID'=>$detail->EventID])}}" class="btn btn-primary"><button type="button">I'm Interested</button></a>
        @foreach($organiser as $detail)
          <dt><a href="mailto:{{$detail->Email}}">Email the event organiser: {{$detail->Email}}</a></dt>
        @endforeach

      </dl>
    @endforeach

    @if (count($errors) > 0)
      <div class="alert alert-danger">
          <ul>
              @foreach ($errors->all() as $error)
                  <li>{{ $error }}</li>
              @endforeach
          </ul>
      </div>
    @endif

 </body>
</html>
