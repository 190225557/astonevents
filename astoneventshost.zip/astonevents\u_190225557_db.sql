-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 07, 2021 at 03:47 PM
-- Server version: 5.7.34-0ubuntu0.18.04.1
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u_190225557_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `EventID` bigint(20) UNSIGNED NOT NULL,
  `OrganiserID` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `DateAndTime` datetime DEFAULT NULL,
  `Description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Location` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `InterestRank` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`EventID`, `OrganiserID`, `Name`, `Category`, `DateAndTime`, `Description`, `Location`, `InterestRank`) VALUES
(1, 8, 'qpzhujipdaqhyoynktf', 'Other', '1996-01-01 13:51:51', 'aeedwepbwemegfzvzfu', 'mktgbxnmfopzlwmyrhy', 631),
(2, 4, 'wcszprtgujlucxoovrf', 'Other', '1992-07-05 04:49:58', 'turblwxugjztibvurkz', 'zpdkdnmalwlbblrhmaz', 780),
(3, 9, 'fobysaelacviangarxb', 'Sport', '1999-01-07 23:20:41', 'gynhcysaxyayzfabdtt', 'ylaojsujzpkytwknwwn', 184),
(4, 9, 'msffuxduegtsljsbiqp', 'Other', '2018-08-27 23:19:15', 'knlpptegmzldjjpzply', 'ljyywzssnyrvqrlsvcc', 106),
(5, 2, 'fueogeiligfpwqrzdwg', 'Other', '1970-10-22 20:36:34', 'sjithxhxmtoimtmvamn', 'yfnytevoyonpitiqcfh', 30),
(6, 9, 'wcaaqsciqtgcnivqfmk', 'Culture', '2015-09-10 23:32:26', 'vkvunrgjxmmyoiwtsic', 'iilbovjgnqbywhhoxbo', 711),
(7, 3, 'xrzachetoieikdusqaz', 'Culture', '1976-06-30 23:15:47', 'wlakgvplujqjbuwylwa', 'wixwwquahlsxwnihtlu', 747),
(8, 8, 'uwivditiljnvbniegdi', 'Other', '1994-08-16 11:11:09', 'nanuxcrqfnzcglimzqz', 'xshhmeaeibezdtfsvvc', 632),
(9, 1, 'fdlcaeqctqbinjpwfjq', 'Culture', '1980-01-18 18:22:22', 'lerhrmvvsleqrcynrgv', 'ticgzixqxwfqrkibpdt', 703),
(10, 10, 'uruftnoxnfcvizmuvyg', 'Culture', '2005-02-09 05:50:20', 'yohdxvjwrlfoaddiadg', 'wvwkgmwzpriqloziznc', 149),
(16, 11, 'Test Event 1', 'Sport', '2021-10-21 20:30:00', 'Test Description', 'Test Location', 0),
(17, 11, 'Test Event 2', 'Culture', '2021-12-02 19:30:00', 'Test Description 2', 'Test Location', 0),
(18, 11, 'Test Event 3', 'Other', '2022-03-24 18:30:00', 'Test Description 3', 'Test Location 3', 0);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(4, '2021_06_24_091826_create_organisers_table', 1),
(7, '2021_06_24_100723_create_categories_table', 1),
(13, '2014_10_12_000000_create_users_table', 2),
(14, '2014_10_12_100000_create_password_resets_table', 2),
(15, '2019_08_19_000000_create_failed_jobs_table', 2),
(16, '2021_06_24_094947_create_events_table', 2),
(17, '2021_06_24_095958_create_photos_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `EventID` bigint(20) UNSIGNED NOT NULL,
  `Photo1` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Photo2` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Photo3` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`EventID`, `Photo1`, `Photo2`, `Photo3`) VALUES
(3, 'dbrjsiktkjmszjhieeb.jpg', 'jvvegyeqddtkftusbgp.jpg', 'qqgxcnhshwjwrhkpjem.jpg'),
(7, 'ellmyhiblijhejpulux.jpg', 'dwqcmpkzunngtnhpbfq.jpg', 'djthviomustxpazvzuk.jpg'),
(5, 'scnlvugcimztphdsngn.jpg', 'khjrotqzscndpguvseu.jpg', 'ufzftaalrpcxfhxkghi.jpg'),
(9, 'vhtoxghduzkgqxwfxjm.jpg', 'ujpmqklrejgvbuubpnk.jpg', 'sykqzvurijemvizosqb.jpg'),
(8, 'gnsrtapjdigpxmprpho.jpg', 'ropbyuedcekpzhlofci.jpg', 'spvpjsfsjqxikpbkvqh.jpg'),
(4, 'hculzhpplvqmzrzdlid.jpg', 'lxdcguozfzffdzwdjfn.jpg', 'ezbseonqcturvmefucj.jpg'),
(1, 'jyfhogtkhjlowodlyie.jpg', 'vgjaxdnpialvhwyvhkn.jpg', 'sdadqmpyrqjzutmmfee.jpg'),
(2, 'trwiocjeblmppqinmia.jpg', 'ysyrdorzyoacrzyrtuk.jpg', 'uexmwzqebnkrzcfpade.jpg'),
(10, 'ljkszsgvcxwyfwnrgsq.jpg', 'qebatcjgtazcasdbtur.jpg', 'fnmymazdbxstmwzonmp.jpg'),
(6, 'ncicvoerbjqdaxqqxub.jpg', 'ebwyawhduvmeyxodrfl.jpg', 'bxuiskartowfaxrwpyu.jpg'),
(16, 'photo/WWWUxYBCTyxQUEdugF32dgec52apmVd4JH3YgycX.png', 'photo/etlRCyCbYHnk46S0MKb7hGz8NgER1CnxxNYvJz2n.png', 'photo/17UJNP7Kq5tngX7XvIRZInHA7lHEonbKlIf5F5Th.png'),
(17, 'photo/4SB0Y0LiuhwX9LYONwDOlWXvfsrFYNNtPlxm474I.png', 'photo/4bamr5ej7xW2zDBH845311lJsST36CMg5ogd8LtR.png', 'photo/YgkBT3CjznMKqLvmOsUwdUZpPnIgAOiY4H9f3DJm.png'),
(18, 'photo/hWBvZCKVppeHAuW59HtdR17PKMLN09wfKreLoQnh.png', 'photo/TgcqCa0Fi9XG9AsT1rsg8tfcE4AcFHnVvtLYvIPt.png', 'photo/ficVTrxOLE4YROlSxLRhEdQelUeVcEMjJsYtgRuo.png');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `OrganiserID` bigint(20) UNSIGNED NOT NULL,
  `Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `EmailVerifiedAt` timestamp NULL DEFAULT NULL,
  `Phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`OrganiserID`, `Name`, `Email`, `EmailVerifiedAt`, `Phone`, `Password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'egqzmoviruexyteyggd', 'zsdzsestyeucynfedxy@gmail.com', NULL, '47126056819', '$2y$10$yWmO0rjADrw2lern/o6z5.uiBh4azJ5nwVN6B4f8me3GdbkZMbOpO', NULL, NULL, NULL),
(2, 'vvwyfqannweodsdcdnd', 'pkwlaynshpwstavxrsp@gmail.com', NULL, '52671453521', '$2y$10$BDudeMx0LTsxUisTPmS07eGpf6sIxT.EYnCFvhC8nPxYmvcJw5VBq', NULL, NULL, NULL),
(3, 'pjzusdgsethrjbvwvnl', 'opojctcdyisxkeqfwna@gmail.com', NULL, '65991633338', '$2y$10$7Q3MqO/duS6AUlQRTOTqO.XkJ2Du9hF98WTYG4GvPeMdNzm2uqA72', NULL, NULL, NULL),
(4, 'gawdnlzrcyrnxfnhbzr', 'ftdabqdofhndvlvtxrq@gmail.com', NULL, '86437942561', '$2y$10$iyqU9mETN8EoOs0NBSu7YODO8Q4PeAo/hGrOT9OKc5WFk3VJNJsgy', NULL, NULL, NULL),
(5, 'uzahfvchzsztotxgnit', 'fdkxcwiieefcmzitjsn@gmail.com', NULL, '73809958433', '$2y$10$9kklSiLpmGivsHPY2PN5DueIbxOndHuhaBKB9AKQ6LEy1.YYdhmla', NULL, NULL, NULL),
(6, 'efzhyhjhlgyhhilquen', 'vpjruinstirryolxtfy@gmail.com', NULL, '43574431845', '$2y$10$2rmcbdH.ic36d4Lp/OEZ3uF6jZT5lgwHNgxIWeL.m/CCo98SEOzme', NULL, NULL, NULL),
(7, 'yvdchkptrzbtkaqztif', 'afmlnxjuroslojgageu@gmail.com', NULL, '50456395078', '$2y$10$nTNHUZRGdV/rqdsHTY/exeXrNKFXfINXekvT80sfV3dC51JGYdgFW', NULL, NULL, NULL),
(8, 'qwtnrdsdpegocogcwcf', 'dhoooykpbggbpekwzjv@gmail.com', NULL, '85546453916', '$2y$10$TRGELLmASEYzAzh49yXKweVI85wYDQQ6fvKzB2hHdxfSOgJaHClse', NULL, NULL, NULL),
(9, 'jivokmbrutlgloxmukq', 'kjhwpirjryjjczlfeqc@gmail.com', NULL, '44657882134', '$2y$10$yAhzWwgSe5oXSRjmsqmeH.UBd7KqrPEPX7IZVH.QIVrSYh0tI0m2C', NULL, NULL, NULL),
(10, 'nojetsizruihfqhpfsi', 'dxqfqyfbpchblddlvft@gmail.com', NULL, '79751158231', '$2y$10$HNcc.FtaX4tJR9NdmxKBEeQrQSHQzUS9JA.NQyAccrn21as3U2nQm', NULL, NULL, NULL),
(11, 'admin', 'admin@gmail.com', NULL, '07550509176', '$2y$10$xWsygAvzz/vENvbiCgHTeOQZey4wGDHvD2uN/c1LvheY7tpEAWnTS', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventID`),
  ADD KEY `events_organiserid_foreign` (`OrganiserID`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD KEY `photos_eventid_foreign` (`EventID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`OrganiserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `EventID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `OrganiserID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_organiserid_foreign` FOREIGN KEY (`OrganiserID`) REFERENCES `users` (`OrganiserID`) ON DELETE CASCADE;

--
-- Constraints for table `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `photos_eventid_foreign` FOREIGN KEY (`EventID`) REFERENCES `events` (`EventID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
