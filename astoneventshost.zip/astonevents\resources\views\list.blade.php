<!DOCTYPE html>
<table>
 <thead>
   <tr>
   <th> ID</th>
   <th> Name</th>
   <th> Date & Time </th>
   <th> Description </th>
   <th> Location </th>
   <th> Photo </th>
   <th> Interest Rank </th>
   </tr>
 </thead>
 <tbody>
 @foreach($events as $event)
   <tr>
   <td> {{$event->id}} </td>
   <td> {{$event->name }} </td>
   <td> {{$event->datetime }} </td>
   <td> {{$event->description }} </td>
   <td> {{$event->location }} </td>
   <td> {{$event->photo }} </td>
   <td> {{$event->interest }} </td>
   </tr>
 @endforeach
 </tbody>
</table>
